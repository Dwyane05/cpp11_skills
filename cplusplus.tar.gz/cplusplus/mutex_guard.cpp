#include <pthread.h>
#include <boost/noncopyable.hpp>

class MutexLock : boost::noncopyable
{
public:
    MutexLock()
    { pthread_mutex_init(&mutex_, nullptr);}

    ~MutexLock()
    { pthread_mutex_destroy(&mutex_); }

    void lock()
    { pthread_mutex_lock(&mutex_); }

    void unlock()
    { pthread_mutex_unlock(&mutex_); }

    pthread_mutex_t * getPthreadMutex()
    { return &mutex_; }

private:
    pthread_mutex_t     mutex_;

};

class MutexLockGuard : boost::noncopyable
{
public:
    MutexLockGuard()
    { mutex_.lock(); }

    ~MutexLockGuard()
    { mutex_.unlock(); }

private:
    MutexLock   &mutex_;

};

#define     MutexLockGuard(x)       static_assert(false, "missing mutex guard var name")

class Condition : boost::noncopyable
{
public:
    Condition()
    { pthread_cond_init(&pcond_, nullptr); }

    ~Condition()
    { pthread_cond_destroy(&pcond_); }

    void wait()
    { pthread_cond_wait(&pcond_, mutex_.getPthreadMutex()); }

    void notify()
    { pthread_cond_signal(&pcond_); }

    void notifyAll()
    { pthread_cond_broadcast(&pcond); }

private:
    MutexLock       &mutex_;
    pthread_cond_t  pcond_;
};

class CountDownLatch
{
public:
    CountDownLatch( int count )
        : count_(count),
          mutex_(),
          condition_()
    {}

private:
    int count_;
    MutexLock   mutex_;
    Condition   condition_;
};




