#include <iostream>
#include <deque>
#include <vector>
using namespace std;
int main()
{
	deque<int> di{1,2,3,4,5};
	for(int i:di)
		cout<<i<<" ";
	cout<<endl;
 
	di.clear();
	cout<<"after di.clear()"<<endl;
	for(int i:di)
		cout<<i<<" ";
	cout<<endl;
	cout << di.size() << endl; 
}

