
#include <opencv2/opencv.hpp>

#include "ThreadPool.h"
#include "CountDownLatch.h"
#include "CurrentThread.h"
#include "Logging.h"

#include <stdio.h>
#include <unistd.h>  // usleep
#include <dirent.h>
#include <sys/time.h>   //gettimeofday
#include <vector>
#include <string>

using namespace std;

vector<string> list_target_files(string fileFolderPath)
{
    if( fileFolderPath.at(fileFolderPath.length() - 1) != '/')
        fileFolderPath.append("/");
    vector<string> files;
    struct dirent *ptr;
    DIR *dir;
    dir = opendir(fileFolderPath.c_str());
    if( NULL == dir ){
        LOG_ERROR << "Open src images folder: " << fileFolderPath
                  <<" error,check config.js {src_pics_path}";
        files.clear();
        return files;
    }

    while( (ptr = readdir(dir)) != NULL ){
        if( ptr->d_name[0] == '.'){
            continue;
        }
        files.push_back(fileFolderPath + ptr->d_name);
    }

    closedir(dir);
    return files;
}

void print()
{
  printf("tid=%d\n", lmp_tool::CurrentThread::tid());
}

static void color_transfer_with_spilt( cv::Mat &input, std::vector<cv::Mat> &chls )
{
    cv::cvtColor( input, input, cv::COLOR_BGR2YCrCb);
    cv::split( input, chls );
}

static void color_retransfer_with_merge( cv::Mat &output, std::vector<cv::Mat> &chls )
{
    cv::merge( chls, output );
    cv::cvtColor( output, output, cv::COLOR_YCrCb2BGR );
}

cv::Mat img_equalize( cv::Mat &src )
{
    cv::Mat ycrcb = src.clone();
    cv::Mat result;
    std::vector<cv::Mat> channels;

    color_transfer_with_spilt(ycrcb, channels);
    // Equalize the Y channel only
    equalizeHist( channels[0], channels[0] );
    color_retransfer_with_merge(result, channels);
    return result;
}

void image_deal(const std::string& str)
{
    cv::Mat image = cv::imread(str, cv::IMREAD_COLOR);
    if( image.empty() ){
        usleep(100*1000);
        return;
    }
    image = img_equalize(image);
    cv::cvtColor(image, image, cv::COLOR_BGR2GRAY);
//    printf("tid=%d end\n", lmp_tool::CurrentThread::tid());

}

void test(int maxSize)
{
    struct timeval start;
    struct timeval end;
    gettimeofday(&start,NULL);
    LOG_WARN << "Test ThreadPool with max queue size = " << maxSize;
    string fileFolderPath = "/home/joinus/temp/cplusplus/use_lmp_tool/joinus_facelib";
    vector<string> image_list = list_target_files(fileFolderPath);
    if( image_list.empty() )
      return;

    lmp_tool::ThreadPool pool("MainThreadPool");
    pool.setMaxQueueSize(maxSize);
    pool.start(10);

    LOG_WARN << "Beginning";

    for (unsigned int i = 0; i < image_list.size(); ++i){
    pool.run(std::bind(image_deal, image_list.at(i)));
    }
    LOG_WARN << "Done";

    lmp_tool::CountDownLatch latch(1);
    pool.run(std::bind(&lmp_tool::CountDownLatch::countDown, &latch));
    latch.wait();
    pool.stop();
    gettimeofday(&end,NULL);
    LOG_INFO << "_build_feature_list time elapsed " <<
          (static_cast<double>(end.tv_sec-start.tv_sec)*1000000+static_cast<double>(end.tv_usec-start.tv_usec))/1000000.0;

}

int main()
{
  test(0);
}

