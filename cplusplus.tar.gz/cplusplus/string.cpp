#include <string>
#include <iostream>

using namespace std;

int main( int argc, char *argv[] )
{
	string test = "abc!/";
	if( test.at(test.length()-1) == '/' )
		cout << "euqal /" << endl;

	cout << test << endl; 
}
