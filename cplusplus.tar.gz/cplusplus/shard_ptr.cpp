#include <memory>
#include <iostream>
using namespace std;

struct AStruct;
struct BStruct;

struct AStruct {
    std::shared_ptr<BStruct> bPtr;
    ~AStruct() { cout << "AStruct is deleted!"<<endl; }
};

struct BStruct {
    std::shared_ptr<AStruct> APtr;
    ~BStruct() { cout << "BStruct is deleted!" << endl; }
};


int main()
{
	std::shared_ptr<AStruct> ap(new AStruct);
    	std::shared_ptr<BStruct> bp(new BStruct);
  //  	ap->bPtr = bp;
 //  	bp->APtr = ap;
	return 0;
}
