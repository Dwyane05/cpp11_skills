/**
 * This work copyright Chao Sun(qq:296449610) and licensed under
 * a Creative Commons Attribution 3.0 Unported License(https://creativecommons.org/licenses/by/3.0/).
 */

#ifndef NET_TEST_TIMER_TEST_CASE_H
#define NET_TEST_TIMER_TEST_CASE_H

namespace netty {
    namespace test {
        class TimerTest {
        public:
            static void Run();
        };
    }
}

#endif //NET_TEST_TIMER_TEST_CASE_H
