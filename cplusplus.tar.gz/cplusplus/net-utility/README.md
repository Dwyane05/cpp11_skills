# net-utility

本c++ sdk封装了socket编程协议栈worker复用的功能，当前只实现了posix下的tcp，但是接口都有所预留，方便扩展。

## 说明
- netty == net utility
