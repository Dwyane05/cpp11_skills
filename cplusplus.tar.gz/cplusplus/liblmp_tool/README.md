# liblmp_tool
Linux Multi pthread tools: include Mutex、Condition、Atomic、ThreadPool、BlockQueue......

#BUILD
./build.sh

#INSTALL
./build.sh install
